#!/usr/bin/env python

from distutils.core import setup

setup(name='nrf24',
      version='0.0.1',
      description='Python port of the RF24 library for NRF24L01+ radios',
      py_modules=['nrf24'],
     )
